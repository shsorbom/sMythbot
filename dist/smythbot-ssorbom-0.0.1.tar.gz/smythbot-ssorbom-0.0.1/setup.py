import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name = "smythbot-ssorbom",
    version = "0.0.1",
    author = "Shawn Sörbom",
    description = " Matrix bot to control a Mythtv DVR",
    long_description = long_description,
    long_description_content_type="text/markdown",
    url = "https://github.com/shsorbom/sMythbot",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: GPL 3",
        "Operating System :: Linux",

    ],
    python_requires='>=3.8*',

)